package com.gst.mybaseapp.base.users;

/**
 * author: GuoSongtao on 2019/4/3 11:05
 * email: 157010607@qq.com
 */
public class UserTypes {
    /**
     * N – 无卡
     */
    public static final String NORMAL = "";
    public static final String NOCARD = "N";

}
