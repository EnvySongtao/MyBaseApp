package com.gst.mybaseapp.utils;

public class ClazzTransformHelper {

    /**
     * 不允许外部 new
     */
    private ClazzTransformHelper(){

    }

    public static void list2array(){

    }

    public static void array2list(){

    }
}
