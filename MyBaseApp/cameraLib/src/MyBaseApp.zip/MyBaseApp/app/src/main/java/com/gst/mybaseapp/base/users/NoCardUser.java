package com.gst.mybaseapp.base.users;

import android.content.Context;

/**
 * author: GuoSongtao on 2019/4/3 11:07
 * email: 157010607@qq.com
 */
public class NoCardUser extends User {

    protected NoCardUser(Context context) {
        super(context);
    }
}
